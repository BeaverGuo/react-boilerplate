import path from 'path'
import webpack from 'webpack'
import { isProd } from '../src/shared/util'
import baseConfig from './base'
import defaultSettings from './defaults'


let config = Object.assign({}, baseConfig, {
  cache: true,
  devtool: isProd ? false : 'source-map',
  plugins: [
    new webpack.optimize.OccurrenceOrderPlugin(),
    new webpack.HotModuleReplacementPlugin(),
    new webpack.NamedModulesPlugin(),
    new webpack.NoEmitOnErrorsPlugin(),
  ],
  module: defaultSettings.getDefaultModules()
});

export default config;
