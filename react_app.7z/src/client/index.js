import 'core-js/fn/object/assign'
import React from 'react'
import ReactDOM from 'react-dom'
import { AppContainer } from 'react-hot-loader'

import App from '../components/Main';
import { APP_CONTAINER_SELECTOR } from '../shared/config'

const rootEl = document.querySelector(APP_CONTAINER_SELECTOR)
//make our App a child of react-hot-loader's AppContainer
const wrapApp = (AppComponent, reduxStore) =>
    <Provider store={reduxStore}>
        <BrowserRouter>
            <AppContainer>
                <AppComponent />
            </AppContainer>
        </BrowserRouter>
    </Provider>


// Render the main component into the dom
ReactDOM.render(wrapApp(App, store), rootEl);