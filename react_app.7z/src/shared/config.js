export const WEB_PORT = process.env.PORT || 8080
export const APP_CONTAINER_SELECTOR